package com.khurana.enterprise.khurana;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KhuranaEnterpriseApplicationTests {

	@Test
	void contextLoads() {
	}

}
