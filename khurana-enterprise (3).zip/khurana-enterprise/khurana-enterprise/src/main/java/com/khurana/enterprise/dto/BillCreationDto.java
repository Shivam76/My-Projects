package com.khurana.enterprise.dto;

import java.util.List;

import lombok.Data;

@Data
public class BillCreationDto {

	private List<ProductBill> prodcuts;

	@Data
	public static class ProductBill {
		private String productName;
		private double price;
		private int qty;
		private String hsnCode;
	}
}
