package com.khurana.enterprise.serviceimpl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.khurana.enterprise.dto.BillCreationDto;
import com.khurana.enterprise.dto.BillCreationDto.ProductBill;
import com.khurana.enterprise.entity.BillEntity;
import com.khurana.enterprise.entity.ProductDetails;
import com.khurana.enterprise.entity.SaleEntity;
import com.khurana.enterprise.entity.StockEntity;
import com.khurana.enterprise.repository.BillRepository;
import com.khurana.enterprise.repository.SaleRepository;
import com.khurana.enterprise.repository.StockRepository;
import com.khurana.enterprise.service.BillingService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingServiceImpl implements BillingService {

	private final StockRepository stockRepo;
	private final BillRepository billRepo;
	private final SaleRepository saleRepo;

	@Override
	public BillEntity createBill(String shop, BillCreationDto request, boolean gst, String customerGstNumber) {

		log.info("Creating bill for shop {}", shop);

		BillEntity bill = new BillEntity();
		double totalAmount = 0;
		List<ProductDetails> productList = new ArrayList<>();
		for (ProductBill product : request.getProdcuts()) {
			StockEntity stock = stockRepo.findByNameAndPrice(product.getProductName(), product.getPrice());
			if (stock.getQuantity() < product.getQty()) {
				throw new RuntimeException("Insufficient stock for Product:{}" + product);
			}
					
			double amount = product.getPrice() * product.getQty();
			if (gst)
				amount += amount * 0.05;

			stock.setQuantity(stock.getQuantity() - product.getQty());
			stockRepo.save(stock);

			SaleEntity sale = new SaleEntity();
			sale.setProductName(product.getProductName());
			sale.setPrice(product.getPrice());
			sale.setQuantity(product.getQty());
			sale.setSaleDate(LocalDate.now());
			saleRepo.save(sale);
			ProductDetails productDetails=new ProductDetails();
			productDetails.setAmount(amount);
			productDetails.setProductName(product.getProductName());
			productDetails.setQuantity(product.getQty());
			productDetails.setHsnCode(stock.getHsnCode());
			productList.add(productDetails);
			totalAmount=totalAmount+amount;
		}
		bill.setProducts(productList);
		bill.setShopName(shop);
		bill.setTotalAmount(totalAmount);
		bill.setCompanyName("Khurana Enterprise");
		bill.setCustomerGstNumber(customerGstNumber);
		bill.setOwnerAddress("Naveen Nagar");
		bill.setOwnerGstNumber("89349394");
		bill.setGstApplied(gst);
		bill.setBillDate(LocalDateTime.now());
		
		return billRepo.save(bill);
	}
}
