package com.khurana.enterprise.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.khurana.enterprise.entity.SaleEntity;
import com.khurana.enterprise.repository.SaleRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/sales")
@RequiredArgsConstructor
public class SalesController {
	private final SaleRepository repo;

	@GetMapping("/day")
	public List<SaleEntity> day() {
		LocalDate d = LocalDate.now();
		return repo.findBySaleDateBetween(d, d);
	}

	@GetMapping("/week")
	public List<SaleEntity> week() {
		return repo.findBySaleDateBetween(LocalDate.now().minusDays(7), LocalDate.now());
	}

	@GetMapping("/month")
	public List<SaleEntity> month() {
		return repo.findBySaleDateBetween(LocalDate.now().minusMonths(1), LocalDate.now());
	}
}