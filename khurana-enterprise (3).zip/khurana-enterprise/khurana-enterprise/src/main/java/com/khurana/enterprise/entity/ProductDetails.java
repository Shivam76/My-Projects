package com.khurana.enterprise.entity;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Embeddable
@Data
public class ProductDetails {

	private String productName;
	private double amount;
	private int quantity;
	private int hsnCode;
}
