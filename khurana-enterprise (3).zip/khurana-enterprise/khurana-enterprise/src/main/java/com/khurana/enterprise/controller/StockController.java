package com.khurana.enterprise.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.khurana.enterprise.dto.AddProductRequest;
import com.khurana.enterprise.entity.StockEntity;
import com.khurana.enterprise.service.StockService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/stock")
@RequiredArgsConstructor
@Slf4j
public class StockController {
	private final StockService service;

	@GetMapping
	public List<StockEntity> getAll() {
		return service.getAllStock();
	}

	@GetMapping("/{name}")
	public List<StockEntity> byName(@PathVariable String name) {
		return service.getAllStock().stream().filter(s -> s.getName().equals(name)).toList();
	}

	@GetMapping("/{name}/{price}")
	public StockEntity byNamePrice(@PathVariable String name, @PathVariable int price) {
		return service.getStockByNameAndPrice(name, price);
	}

	@PutMapping("/{name}/{price}/{qty}")
	public StockEntity update(@PathVariable String name, @PathVariable int price, @PathVariable int qty) {
		return service.updateStock(name, price, qty);
	}

	@Operation(summary = "Add product to stock", description = "Adds a biscuit product with name, price and quantity")
	@ApiResponses({ @ApiResponse(responseCode = "201", description = "Product added successfully"),
			@ApiResponse(responseCode = "400", description = "Invalid input") })
	@PostMapping("/add")
	public ResponseEntity<StockEntity> addProduct(@Valid @RequestBody AddProductRequest request) {

		log.info("Adding product: {} price: {}", request.getName(), request.getPrice());

		StockEntity stock = service.addProduct(request);

		return ResponseEntity.status(HttpStatus.CREATED).body(stock);
	}
}