package com.khurana.enterprise.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.khurana.enterprise.dto.AddProductRequest;
import com.khurana.enterprise.entity.StockEntity;
import com.khurana.enterprise.repository.StockRepository;
import com.khurana.enterprise.service.StockService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class StockServiceImpl implements StockService {

	private final StockRepository repo;

	@Override
	public List<StockEntity> getAllStock() {
		log.info("Fetching all stock items");
		return repo.findAll();
	}

	@Override
	public List<StockEntity> getStockByName(String name) {
		log.info("Fetching stock for name: {}", name);
		return repo.findByName(name);
	}

	@Override
	public StockEntity getStockByNameAndPrice(String name, int price) {
		return repo.findByNameAndPrice(name, price);
	}

	@Override
	public StockEntity addProduct(AddProductRequest request) {
		
		StockEntity alreadyStock=repo.findByNameAndPrice(request.getName(), request.getPrice());
		if(alreadyStock!=null)
		{
			
			alreadyStock.setQuantity(alreadyStock.getQuantity()+request.getQuantity());
			return repo.save(alreadyStock);
		}
		StockEntity s = new StockEntity();
		s.setName(request.getName());
		s.setPrice(request.getPrice());
		s.setQuantity(request.getQuantity());
		s.setHsnCode(request.getHsnCode());
		return repo.save(s);
	}

	@Override
	public StockEntity updateStock(String name, int price, int quantity) {
		StockEntity stock = getStockByNameAndPrice(name, price);
		stock.setQuantity(stock.getQuantity()+ quantity);
		return repo.save(stock);
	}
}
