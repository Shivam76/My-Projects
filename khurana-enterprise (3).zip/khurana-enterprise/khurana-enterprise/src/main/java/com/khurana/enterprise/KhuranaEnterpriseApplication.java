package com.khurana.enterprise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KhuranaEnterpriseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KhuranaEnterpriseApplication.class, args);
	}

}
