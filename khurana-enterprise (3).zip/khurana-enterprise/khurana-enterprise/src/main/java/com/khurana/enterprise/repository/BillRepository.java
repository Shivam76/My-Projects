package com.khurana.enterprise.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khurana.enterprise.entity.BillEntity;

@Repository
public interface BillRepository extends JpaRepository<BillEntity, Long> {
}