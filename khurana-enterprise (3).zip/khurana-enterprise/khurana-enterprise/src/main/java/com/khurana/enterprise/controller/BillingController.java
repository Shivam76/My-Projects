package com.khurana.enterprise.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.khurana.enterprise.dto.BillCreationDto;
import com.khurana.enterprise.entity.BillEntity;
import com.khurana.enterprise.service.BillingService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/bill")
@RequiredArgsConstructor
public class BillingController {
	
	private final BillingService service;

	@PostMapping
	public BillEntity create(@RequestParam String shopName, @RequestBody BillCreationDto request,@RequestParam boolean gst,String customerGstNumber) {
		return service.createBill(shopName, request, gst,customerGstNumber);
	}
}